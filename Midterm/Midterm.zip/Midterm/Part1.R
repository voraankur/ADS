
library(lubridate)
library(plyr)
library(dplyr)
library(stringr)
library(httr)
library(jsonlite)
library(RCurl)
library(devtools)
library(XML)
library(ggmap)
library(weatherData)
library(zoo)

# read data from csv
masked <- read.csv("C:\\Users\\Ankur\\Desktop\\ADS\\ADS_Assignments\\Midterm\\Finland_masked.csv", stringsAsFactors = FALSE)
building_address <- read.csv("C:\\Users\\Ankur\\Desktop\\ADS\\ADS_Assignments\\Midterm\\Finland_addresses_area.csv", stringsAsFactors = FALSE)

# selecting type 'elect' or 'Dist_Heating'
masked1 <- masked %>% filter(masked$type == 'elect' | masked$type == 'Dist_Heating')
write.csv(masked1,file="C:\\Users\\Ankur\\Desktop\\ADS\\ADS_Assignments\\Midterm\\masked1.csv")

# Filling values for missing building
masked1$vac[masked1$BuildingID %in% c(81909)] <- 'Building 27'
masked1$vac[masked1$BuildingID %in% c(82254, 83427, 84681)] <- 'Building 9'

# find unique combination of building id and meternumb
unique_comb <- unique(masked1[,c('BuildingID', 'vac', 'meternumb')])

# creating date and hour data for 2013
time_index <- as.data.frame(seq(from = as.POSIXct("2013-01-01 00:00"), 
                  to = as.POSIXct("2013-12-31 23:00"), by = "hour"))
colnames(time_index) <- c("Date_Time")

#extract date from DateTime
time_index$date <- date(time_index$Date_Time)

#extract hour from DateTime
time_index$hour <- hour(time_index$Date_Time)

# remove extra column
time_index <- subset(time_index, select =c(date,hour))

# remove '-' from date 
time_index$date <- gsub("-", "", time_index$date)

# merged time series with the unique combination (for 78 models)
merged_timeseries <- merge(unique_comb, time_index)

# Combine row data for all the 78 models
complete_timeseries <- merge(masked1, merged_timeseries, by = c("BuildingID", "vac", "meternumb", "date", "hour"), all.y = TRUE)

# find week of day starting from Sunday as 0
complete_timeseries$weekOfDay<-wday(ymd(complete_timeseries$date))-1

# find month from data column
complete_timeseries$month<-month(ymd(complete_timeseries$date))

# find if day is weekday or not (for weekday valus is 1 and for weekend value is 0)
complete_timeseries$Weekday<-ifelse(complete_timeseries$weekOfDay %in% c(0,6), 0, 1)

# find basehour based on condition
baseHour<-c(0:4, 22:23)
complete_timeseries$baseHourFlag<-ifelse(complete_timeseries$hour %in% baseHour, TRUE, FALSE)

# find if particular day is holiday
holiday<-c(20130101, 20130106, 20130329, 20130331, 20130401, 20130501, 20130509, 20130519, 20130622, 20131102, 20131206, 20131225, 20131226)
complete_timeseries$isHoliday<-ifelse(complete_timeseries$date %in% holiday, 1, 0)

# rename vac to building 
colnames(complete_timeseries)[2] <- "building"

# handling NA values
#complete_timeseries <- na.locf(complete_timeseries)

# Write clean data into csv file
write.csv (complete_timeseries,"C:\\Users\\Ankur\\Desktop\\ADS\\ADS_Assignments\\Midterm\\complete_ts.csv")

# merge building address to time series data
merged_building_ts <- merge(complete_timeseries, building_address, by = c("building"), all.x = TRUE)

# remove unwanted column (here, address column needs to be deleted)
merged_building_ts <- subset(merged_building_ts, select = - X..address)

# find consumption by sq meter area
merged_building_ts$norm_consumption <- merged_building_ts$Consumption / merged_building_ts$area_floor._m.sqr


#-------------AirPort Data--------------

# lattitude and longitude for 32 buildings
lonlat <- geocode(as.character(building_address$X..address))
lonlat <- lonlat[-32,]
lonlat

# get weather data for all the buildings
# Fetching weatherdata using 'WeatherData' package
weatherData <- NULL
for(i in 1:nrow(lonlat)){
  longitude<-lonlat$lon[i]
  latitude<-lonlat$lat[i]
  
  print(latitude)
  print(longitude)
  
  apiUrl<-paste("http://api.wunderground.com/auto/wui/geo/GeoLookupXML/index.xml?query=",
                latitude,",",longitude, sep="", collapse=NULL)
  print(apiUrl)
  apiData <- xmlParse(apiUrl)
  
  stationFunction <- function(x){
    xname <- xmlName(x)
    xattrs <- xmlAttrs(x)
    c(sapply(xmlChildren(x), xmlValue), name = xname, xattrs)
  }
  
  airportStationData <- as.data.frame(t(xpathSApply(apiData, "//*/airport/station", stationFunction)), 
                                      stringsAsFactors = FALSE)
  print(airportStationData)
  
  loc <- c(lat = latitude, lng = longitude)
  airportStationData$lat <- as.numeric(airportStationData$lat)
  airportStationData$lon <- as.numeric(airportStationData$lon)
  
  
  dists <- geosphere::distHaversine(as.numeric(loc[c('lng', 'lat')]), 
                                    airportStationData[, c('lon', 'lat')])
  
  min.n <- function(x,n,value=TRUE){
    s <- sort(x, index.return=TRUE)
    if(value==TRUE){s$x[n]} else{s$ix[n]}}
  
  icao <- NULL
  
  startindex <- 1
  
  for (ii in seq(startindex, length(dists))){  
    
    nearestAirport <- airportStationData[match(min.n(dists,ii),dists), ]
    icao <- nearestAirport$icao
    if(icao != '')
      break
  }
  print(i)
  print(icao)
  
  # finding weather data for each airport station (not using for this assignment though)
  
  #each_date_weather <- getWeatherForDate(icao, start_date = "2013-01-01",end_date = "2013-12-31", opt_custom_columns=TRUE, opt_detailed=TRUE,custom_columns=c(2,3,4,5,6,7,8,9,10,11,12,13,14))
  
  #weatherData <-rbind(weatherData, each_date_weather)
}

Midterm_weatherData <- getWeatherForDate(icao, start_date = "2013-01-01",end_date = "2013-12-31", opt_custom_columns=TRUE, opt_detailed=TRUE,custom_columns=c(2,3,4,5,6,7,8,9,10,11,12,13,14))

# Write final clean data into csv file
write.csv (Midterm_weatherData,"C:\\Users\\Ankur\\Desktop\\ADS\\ADS_Assignments\\Midterm\\mt_weatherData.csv")
mt_weatherData <- read.csv("C:\\Users\\Ankur\\Desktop\\ADS\\ADS_Assignments\\Midterm\\mt_weatherData.csv")

wData <- mt_weatherData

#extract date from Time
wData$date <- date(wData$Time)

#extract hour from Time
wData$hour <- hour(wData$Time)

#extract minute from Time
wData$minute <- minute(wData$Time)

#sort data based on date, hour and minute(desc) and select unique rows
wData_sort <- with(wData, wData[order(date,hour,-minute),]) 
wData_sort1<-wData_sort[!duplicated(wData_sort[c("date","hour")]),]

#remove rows with date NA
wData_sort1<-wData_sort1[!(is.na(wData_sort1$date)),]

#Removing extra columns
wData_sort1 <- subset(wData_sort1, select = c(-X, -minute))

# update date in require format for merging
wData_sort1$date <- gsub("-", "", wData_sort1$date)

# merge time-series data with weather data
merged_time_weather<-merge(merged_building_ts,wData_sort1, by= c("date","hour"), all.x = TRUE)

# remove NA in type and consumption
merged_typeRemoveNA <- merged_time_weather[!is.na(merged_time_weather$type),]

# ordering columns
ordered_complete_data <- with(merged_typeRemoveNA, merged_typeRemoveNA[order(BuildingID,meternumb,date,hour),])

# handling NA values
complete_data <- na.locf(ordered_complete_data)

# data clean up
complete_data$TemperatureF[complete_data$TemperatureF == '-9999.0'] <- NA 
complete_data$Dew_PointF[complete_data$Dew_PointF == '-9999.0'] <- NA
complete_data$Humidity[complete_data$Humidity == 'N/A'] <- NA
complete_data$VisibilityMPH[complete_data$VisibilityMPH == '-9999.0'] <- NA
complete_data$Wind_Direction[complete_data$Wind_Direction == 'Calm' | complete_data$Wind_Direction == 'Variable'] <- NA
complete_data$Wind_SpeedMPH[complete_data$Wind_SpeedMPH == 'Calm'] <- NA
complete_data$Gust_SpeedMPH[complete_data$Gust_SpeedMPH == '-'] <- NA
complete_data$Events[complete_data$Events == ''] <- NA
clean_complete_data <- na.locf(complete_data)

# handing NA values at the beginning for 'Gust_SpeedMPH'
clean_complete_data$Gust_SpeedMPH <- na.locf(clean_complete_data$Gust_SpeedMPH, fromLast = TRUE)

write.csv (clean_complete_data,"C:\\Users\\Ankur\\Desktop\\ADS\\ADS_Assignments\\Midterm\\ordered_complete_data.csv")
