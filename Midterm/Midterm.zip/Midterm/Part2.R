
library(dplyr)

#--------------------- Modelling Tasks

part1_data <- read.csv("C:\\Users\\Ankur\\Desktop\\ADS\\ADS_Assignments\\Midterm\\ordered_complete_data.csv", stringsAsFactors = FALSE)

copyOFPart1Data <- part1_data %>%
  group_by(BuildingID, type, meternumb, Weekday, month, isHoliday) %>%
  summarise(base_hr_usage = mean(Consumption), baseHourFlag = 'TRUE')

merge_base_hr_data <- merge(part1_data, copyOFPart1Data, by=c("BuildingID","type", "meternumb", "Weekday", "month", "isHoliday"))

merge_base_hr_data$Base_Hour_Class<-ifelse(merge_base_hr_data$Consumption>merge_base_hr_data$base_hr_usage, "High", "Low")

# ordering columns
merge_base_hr_data <- with(merge_base_hr_data, merge_base_hr_data[order(BuildingID,meternumb,date,hour),])

write.csv (merge_base_hr_data,"C:\\Users\\Ankur\\Desktop\\ADS\\ADS_Assignments\\Midterm\\merge_base_hr_data.csv")



#--------------------- KNN Prediction ---------------------------

require(class)

dataSetkNN<-merge_base_hr_data

#add columns which affect prediction variable
dataSetkNN_subset<- subset(dataSetkNN, select = c(1,3,4,6,8,11,13,14,16,17,22))

#Reorganize and follow the order of the random number dataSetkNN 
group<-runif(nrow(dataSetkNN_subset))

#Normalization function
normalizekNN<-function(x)(return((x-min(x))/(max(x)-min(x))))

#normalizekNN data set 
dataSetkNN_n<-as.data.frame(lapply(dataSetkNN[,c(1,3,4,6,11,13,14,16,17,22)], normalizekNN))
summary(dataSetkNN_n)

#Seperate training and testing dataSetkNN
trainkNN <- dataSetkNN_n[1:10000,]
testkNN <- dataSetkNN_n[10001:15000,]

#Set the normalized consumption as our trainkNNing target as well as testing target
trainkNN_traget <- dataSetkNN_n[1:10000,7]
testkNN_target <- dataSetkNN_n[10001:15000,7]

#kNN model 
m1<-knn(train = trainkNN, test = testkNN,cl = trainkNN_traget, k=100)

#Difference between Predicted result and what was actual consumption
head(table(testkNN_target,m1))

#Find accuracy
accuracy(testkNN_target,m1)



#----------------------- Random Forest Prediction-------------#

library(randomForest)
library(forecast)

#Splitting the data in train and test 
set.seed(415)
trainRandomForest <- merge_base_hr_data[1:10000,]
testRandomForest <- merge_base_hr_data [10001:20000,]

#Apply random forest model
fitRandomForest <- randomForest(norm_consumption ~ hour+TemperatureF+Dew_PointF+Humidity+Sea_Level_PressureIn
                    +VisibilityMPH+Wind_SpeedMPH+Gust_SpeedMPH+WindDirDegrees+base_hr_usage,
                    data=trainRandomForest, importance=TRUE, ntree=50)
summary(fitRandomForest)

#Plotting a graph for top 5 most affected variables
varImpPlot(fitRandomForest, sort = T, main = "Variable Importance", n.var = 5)

#Predict normal consumption
testRandomForest$predicted<- predict(fitRandomForest, testRandomForest)

#Calculate MAPE MAE RMSEvalue
accuracy(testRandomForest$norm_consumption, testRandomForest$predicted)

#Find outliers
testRandomForest$outliers<-ifelse((testRandomForest$norm_consumption-testRandomForest$predicted)
                      >=(2*sd(testRandomForest$norm_consumption-testRandomForest$predicted))
                      , "Outliers", "Not Outliers")


#--------------------Neural Network Prediction---------------------------------
library(XML)
#install.packages("neuralnet")
library(neuralnet)
library(forecast)

part2_data <- read.csv("C:\\Users\\kruti\\Desktop\\ADS\\Midterm\\Part2\\merge_base_hr_data.csv", stringsAsFactors = FALSE)
#Converting the data to numeric
data <- part2_data[, sapply(part2_data, is.numeric)]

#splitting the data into train and test data
train <- data[1:20000,]
test <- data [20001:30000,]

#Applying linear regression
lm.fit <- glm(norm_consumption~BuildingID+meternumb+Weekday+month+isHoliday+hour+TemperatureF
              +Humidity+Sea_Level_PressureIn+VisibilityMPH+Wind_SpeedMPH+Gust_SpeedMPH+WindDirDegrees
              +base_hr_usage, data=train)
summary(lm.fit)

#Predicting the consumption value for test data
pr.lm <- predict(lm.fit,test)
MSE.lm <- sum((pr.lm - test$norm_consumption)^2)/nrow(test)

#Modelling the train data using neuralnet
nn = neuralnet(norm_consumption ~ BuildingID+meternumb+Weekday+month+isHoliday+hour+TemperatureF
               +Humidity+VisibilityMPH+Wind_SpeedMPH+Gust_SpeedMPH+WindDirDegrees
               +base_hr_usage,data = train, hidden = c(4,2))

#View result and plot model
nn$result.matrix
plot(nn)


#Predicting consumption value using neuralnet model
pr.nn <- compute(nn,test[,1:13])
pr.nn_ <- pr.nn$net.result*(max(data$norm_consumption)-min(data$norm_consumption))+min(data$norm_consumption)
test.r <- (test$norm_consumption)*(max(data$norm_consumption)-min(data$norm_consumption))+min(data$norm_consumption)
MSE.nn <- sum((test.r - pr.nn_)^2)/nrow(test)

#Comparing two MSE - linear and neuralnet
print(paste(MSE.lm,MSE.nn))

#Plot real vs predicted lm/predicted nn
par(mfrow=c(1,2))

plot(test$norm_consumption,pr.nn_,col='red',main='Real vs predicted NN',pch=18,cex=0.7)
abline(0,1,lwd=2)
legend('bottomright',legend='NN',pch=18,col='red', bty='n' )

plot(test$norm_consumption,pr.lm,col='blue',main='Real vs predicted lm',pch=18, cex=0.7)
abline(0,1,lwd=2)
legend('bottomright',legend='LM',pch=18,col='blue', bty='n', cex=.95)

# -------------------------------------------KNN Classification------------------------------------
library(caret)
library(randomForest)
library(e1071)
library(forecast)

dataSetkNN_Classification<-merge_base_hr_data

#add columns which affect prediction variable
dataSetkNN_Classification_subset<- subset(dataSetkNN_Classification, select = c(1,3,4,6,8,11,13,14,16,17,22,31))

dataSetkNN_Classification_subset$Base_Hour_Class <- ifelse(dataSetkNN_Classification_subset$Base_Hour_Class %in% "High", 1,0)

#Reorganize and follow the order of the random number dataSetkNN_Classification 
group<-runif(nrow(dataSetkNN_Classification_subset))

#Normalization function
normalizekNN_Classification<-function(x)(return((x-min(x))/(max(x)-min(x))))

#normalizekNN_Classification data set 
dataSetkNN_Classification_n<-as.data.frame(lapply(dataSetkNN_Classification_subset, normalizekNN_Classification))
summary(dataSetkNN_Classification_n)

#Splitting the data in train and test 
set.seed(415)
trainkNN_Classification <- dataSetkNN_Classification_n[1:10000,]
testkNN_Classification <- dataSetkNN_Classification_n [10001:20000,]

#Set the normalized consumption as our trainkNNing target as well as testing target
trainkNN_traget_Classification <- dataSetkNN_Classification_n[1:10000,12]
testkNN_target_Classification <- dataSetkNN_Classification_n[10001:15000,12]

#Apply KNN model
predicted_classification<-knn(train = trainkNN_Classification
                              , test = testkNN_Classification,cl = trainkNN_traget_Classification, k=100)
summary(predicted_classification)

# confusion matrix
knn_confmatrix <- confusionMatrix(predicted, testkNN_Classification$Base_Hour_Class)

# write confustion matrix to csv
str(knn_confmatrix)
tocsv_rfcm <- data.frame(cbind(t(knn_confmatrix$overall),t(knn_confmatrix$byClass)))
write.csv (tocsv_rfcm,"C:\\Users\\Ankur\\Desktop\\ADS\\ADS_Assignments\\Midterm\\KNN_ConfustionMatrix.csv")



#----------------------- Random Forest Classification-------------#

library(randomForest)
library(forecast)

#Splitting the data in train and test 
set.seed(415)
trainRF_Classification <- merge_base_hr_data[1:10000,]
testRF_Classification <- merge_base_hr_data [10001:20000,]
trainRF_Classification$Base_Hour_Class <- ifelse(trainRF_Classification$Base_Hour_Class %in% "High", 1,0)
testRF_Classification$Base_Hour_Class <- ifelse(testRF_Classification$Base_Hour_Class %in% "High", 1,0)

#Apply random forest model
fitRF_Classification <- randomForest(Base_Hour_Class ~ hour+TemperatureF+Dew_PointF+Humidity+Sea_Level_PressureIn
                                +VisibilityMPH+Wind_SpeedMPH+Gust_SpeedMPH+WindDirDegrees+base_hr_usage+Consumption,
                                data=trainRF_Classification, importance=TRUE, ntree=50)
summary(fitRF_Classification)

#Plotting a graph for top 5 most affected variables
varImpPlot(fitRF_Classification, sort = T, main = "Variable Importance", n.var = 5)

#Predict normal consumption
testRF_Classification$predicted<- predict(fitRF_Classification, testRF_Classification)

#rounding off
testRF_Classification$predicted <- round(testRF_Classification$predicted)

# Compute Outlier_day
testRF_Classification$Outlier_day <- ifelse(testRF_Classification$Base_Hour_Class != testRF_Classification$predicted, TRUE,FALSE)

table(testRF_Classification)
write.csv (testRF_Classification,"C:\\Users\\Ankur\\Desktop\\ADS\\ADS_Assignments\\Midterm\\testRF_Classification.csv")

# confusion matrix
rf_confmatrix <- confusionMatrix(testRF_Classification$predicted, testRF_Classification$Base_Hour_Class)

# write confustion matrix to csv
str(rf_confmatrix)
tocsv_rfcm <- data.frame(cbind(t(rf_confmatrix$overall),t(rf_confmatrix$byClass)))
write.csv (tocsv_rfcm,"C:\\Users\\Ankur\\Desktop\\ADS\\ADS_Assignments\\Midterm\\RandomForest_ConfustionMatrix.csv")

library(ROCR)

adult.rf.pred = prediction(testRF_Classification$predicted, testRF_Classification$Base_Hour_Class)

#performance in terms of true and false positive rates
adult.rf.perf = performance(adult.rf.pred,"tpr","fpr")

#plot the curve
plot(adult.rf.perf,main="ROC Curve for Random Forest",col=2,lwd=2)
abline(a=0,b=1,lwd=2,lty=2,col="gray")

#--------------------Neural Network Classification--------------------------------------------

library(XML)
#install.packages("neuralnet")
library(neuralnet)

merge_base_hr_data <- read.csv("C:\\Users\\kruti\\Desktop\\ADS\\Midterm\\Part2\\merge_base_hr_data.csv", stringsAsFactors = FALSE)
#Splitting the data in train and test 
merge_base_hr_data <- merge_base_hr_data[, sapply(merge_base_hr_data, is.numeric)]
set.seed(415)
trainNN_Classification <- merge_base_hr_data[1:10000,]
testNN_Classification <- merge_base_hr_data [10001:20000,]
trainNN_Classification$Base_Hour_Class <- ifelse(trainNN_Classification$Base_Hour_Class %in% "High", 1,0)
testNN_Classification$Base_Hour_Class <- ifelse(testNN_Classification$Base_Hour_Class %in% "High", 1,0)

#Applying linear regression
lm.fit <- glm(Base_Hour_Class~BuildingID+meternumb+Weekday+month+isHoliday+hour+TemperatureF
              +Humidity+Sea_Level_PressureIn+VisibilityMPH+Wind_SpeedMPH+Gust_SpeedMPH+WindDirDegrees
              +base_hr_usage+Consumption, data=trainNN_Classification)
summary(lm.fit)

#Predicting the consumption value for test data
pr.lm <- predict(lm.fit,test)
MSE.lm <- sum((pr.lm - test$norm_consumption)^2)/nrow(test)

#Apply neural network model
fitNN_Classification <- neuralnet(Base_Hour_Class ~ BuildingID+Weekday+month+TemperatureF
                                  +Humidity+Wind_SpeedMPH+Gust_SpeedMPH+base_hr_usage+Consumption,
                                  data = trainNN_Classification, hidden = c(4,2))

#View result and plot model
fitNN_Classification$result.matrix
plot(fitNN_Classification)

#Predicting consumption value using neuralnet model
pr.fitNN_Classification<- compute(fitNN_Classification,testNN_Classification[,1:9])
pr.fitNN_Classification_ <- pr.fitNN_Classification$net.result*(max(merge_base_hr_data$Base_Hour_Class)-min(merge_base_hr_data$Base_Hour_Class))+min(merge_base_hr_data$Base_Hour_Class)
test.r <- (testNN_Classification$Base_Hour_Class)*(max(merge_base_hr_data$Base_Hour_Class)-min(merge_base_hr_data$Base_Hour_Class))+min(merge_base_hr_data$Base_Hour_Class)
MSE.nn <- sum((test.r - pr.fitNN_Classification_)^2)/nrow(testNN_Classification)

#Comparing two MSE - linear and neuralnet
print(paste(MSE.lm,MSE.nn))

#------------------------Hierarchical Clustering
Clustering_data <- read.csv ("C:\\Users\\Ankur\\Desktop\\ADS\\ADS_Assignments\\Midterm\\testRF_Classification.csv")

clusters <- hclust(dist(Clustering_data[, 3:8]))
plot(clusters)

#-----------------------K-means clustering
library(ggplot2)
ggplot(Clustering_data, aes(BuildingID, Consumption, color = base_hr_usage)) + geom_point()

set.seed(400)
kmeans_cluster <- kmeans(Clustering_data[, 3:8], 3, nstart = 20)
kmeans_cluster


wssplot <- function(Clustering_data, nc=15, seed=1234){
  wss <- (nrow(Clustering_data)-1)*sum(apply(Clustering_data,2,var))
  for (i in 2:nc){
    set.seed(seed)
    wss[i] <- sum(kmeans(Clustering_data, centers=i)$withinss)}
  plot(1:nc, wss, type="b", xlab="Number of Clusters",
       ylab="Within groups sum of squares")}

df <- scale(Clustering_data)
wssplot(Clustering_data)                                            
library(NbClust)
install.packages("NbClust")
set.seed(1234)
nc <- NbClust(df, min.nc=2, max.nc=15, method="kmeans")
table(nc$Best.n[1,])

barplot(table(nc$Best.n[1,]), 
        xlab="Numer of Clusters", ylab="Number of Criteria",
        main="Number of Clusters Chosen by 26 Criteria")

